import React, { Component } from 'react';

import './Home.css';

class Home extends Component {

    onFormLogin = (e) => {
        e.preventDefault()
        const username = document.getElementById("username").value 
        const password = document.getElementById("password").value 
        console.log(username, password)
    }

    render () {
        return (
            <div>
            <h1>Admin Login</h1> 
                <form>
                    Username<input type="username" id="username"></input>
                    Password<input type="password" id="password"></input>
                    <button onClick={this.onFormLogin}>Click to Login</button>
                </form>
            </div>
         
        );
    }
}

export default Home;
