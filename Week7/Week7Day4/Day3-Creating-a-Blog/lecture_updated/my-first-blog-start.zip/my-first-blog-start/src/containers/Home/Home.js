import React, { Component } from 'react';

import './Home.css';

class Home extends Component {
    render () {
        return (
            <h1 className="Home">THIS IS MY HOME SCREEN</h1>
        );
    }
}

export default Home; 