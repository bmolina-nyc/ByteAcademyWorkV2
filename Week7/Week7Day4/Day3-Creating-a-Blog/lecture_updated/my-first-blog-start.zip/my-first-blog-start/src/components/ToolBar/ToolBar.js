import React from 'react';
import NavigationItems from '../NavigationItems/NavigationItems';

import './ToolBar.css'

const Toolbar = (props) => (
    <header className="Toolbar">
        <NavigationItems/>
    </header>
)

export default Toolbar; 