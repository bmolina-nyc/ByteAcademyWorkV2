import React, { Component } from 'react';
import {Route} from 'react-router-dom'

import Blog from './containers/Blog/Blog';
import Home from './containers/Home/Home'
import Toolbar from './components/ToolBar/ToolBar'

class App extends Component {
  render() {
    return (
      <div className="App">
      <Toolbar />
      <Route path="/blog" component={Blog}/>
      <Route path="/" component={Home}/>
      </div>
    );
  }
}

export default App;