#! /bin/sh

python3 -m unittest discover tests
