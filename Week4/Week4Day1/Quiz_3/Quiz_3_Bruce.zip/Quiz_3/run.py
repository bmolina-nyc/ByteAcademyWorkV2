from schema import schema
from seed import seed


def run():
  schema()    
  seed()  

if __name__ == "__main__":
        run()
