#! /usr/bin/env python3

from data.schema import schema
from data.seed import seed

schema()
seed()
