## Week 7 Quiz - React

* Create a new react app.

* The app should have two routes, '/' and '/numbers'

* The '/' route shows a welcome message and has a link to numbers.

* The '/numbers' route contains a component called `<NumberButton>` that is an
html element that can receive a click and contain content.

* When the NumberButton is clicked, it creates displays twenty `<Number>` 
elements with a `num=` prop set to 0 to 19.

* A `<Number>` element displays the value of its prop inside of an html
element.
