import React from 'react';


const NumberComponent = (props) => {
    return(
        
        <div><h2>Number: {props.num}</h2></div>
    )
}
export default NumberComponent;

